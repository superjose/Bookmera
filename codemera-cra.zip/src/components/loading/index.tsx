import React, { memo } from 'react';

function Loading() {
  return <p>Loading</p>;
}

export default memo(Loading);

import { styled } from './theme';

export const H1Padded = styled.h1`
  padding-left: 5rem;
  text-transform: capitalize;
`;
